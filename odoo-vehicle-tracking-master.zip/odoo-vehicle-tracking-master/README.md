# odoo-vehicle-tracking
Módulo para rastreo GPS de unidades de transporte de equipo médico
