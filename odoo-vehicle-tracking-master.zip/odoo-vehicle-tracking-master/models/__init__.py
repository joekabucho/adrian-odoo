# -*- coding: utf-8 -*-

from . import inherit_vehicle_view_form
from . import vehicle_tracking
